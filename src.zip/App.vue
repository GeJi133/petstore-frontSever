<template>
  <div id="app">
    <!-- <img src="./assets/logo.png"> -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
  /* @import "../../assets/css/connect.min.css"; */
  /* @import "../../assets/css/admin3.css";
  @import "../../assets/css/dark_theme.css";
  @import "../../assets/css/custom.css";
  @import url("https://fonts.googleapis.com/css?family=Lato:400,700,900&display=swap");
  @import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,700&display=swap");
  @import url("https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp");
  @import "../../assets/plugins/bootstrap/css/bootstrap.min.css";
  @import "../../assets/plugins/font-awesome/css/all.min.css"; */
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
